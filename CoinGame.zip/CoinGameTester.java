public class CoinGameTester {
    public static void main(String[] args) {
        
        CoinGame game = new CoinGame(10, 5); //calls constructor while inputting appropriate values
        game.PlayGame(); //calls PlayGame
        
        //expected output: "Tie Game!""
    }
}