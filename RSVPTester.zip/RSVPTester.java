public class RSVPTester
{
    public static void main(String[] args)
    {
        RSVP info = new RSVP(); //Constructor
        
       
        //Test 1: Attending, Fish, False
        System.out.println("EXPECTED: \nattending \nfish \noption1==option2=false");
        System.out.println("");
        System.out.println("ACTUAL: ");
        info.rsvp(true,4);
        System.out.println("-------------------");
        System.out.println("");
        
        //Test 2: Not attending, Fish, False
        System.out.println("EXPECTED: \nnot attending \nfish \noption1==option2=false");
        System.out.println("");
        System.out.println("ACTUAL: ");
        info.rsvp(false,15);
        System.out.println("-------------------");
        System.out.println("");
        
        //Test 3: Not attending, Chicken, False
        System.out.println("EXPECTED: \nnot attending \nchicken \noption1==option2=false");
        System.out.println("");
        System.out.println("ACTUAL: ");
         info.rsvp(false,2);
        System.out.println("");
        System.out.println("-------------------");
        System.out.println("");
         
        //Test 4: Not attending, Pasta, False 
        System.out.println("EXPECTED: \nnot attending \npasta \noption1==option2=false");
        System.out.println("");
        System.out.println("ACTUAL: ");
        info.rsvp(false,3);
        System.out.println("");
        System.out.println("-------------------");
        System.out.println("");
         
        //Test 5: Attending, Beef, False  
        System.out.println("EXPECTED: \nattending \nbeef \noption1==option2=false");
        System.out.println("");
        System.out.println("ACTUAL: ");
        info.rsvp(true,1);
        System.out.println("-------------------");
    }
}