public class CarRepair
{
    private int mechanicNum;
    private int bayNum; 
    
    public CarRepair(int m, int b){
        mechanicNum = m;
        bayNum = b; 
    }
    
    public int getMechanicNum(){
        return mechanic num;
    }
    
    public int getBayNum(){
        return bayNum; 
    }
    
    
}