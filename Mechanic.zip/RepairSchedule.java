public class RepairSchedule {
    
    private ArrayList<CarRepair> schedule; 
    private int numberOfMechanics;
    
    public RepairSchedule(int n)
    {
        schedule = new ArrayList<CarRepair>();
        numberOfMechanics = n;
    }
    
    public boolean addRepair(int m, int b){
        int theM; 
        int theB; 
        
        (CarRepair x : schedule){
            theM = x.getMechanicNum();
            theB = x.getBayNum();
        }
        
        if (theM==m && theB==b){
            return false; 
        }
        return true; 
    }
    
    public ArraList<Integer> availableMechanics(){
        
    }
    
    public void carOut(int b){
        
    }
}