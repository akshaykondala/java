import java.util.Scanner;

public class StudentTester
{
    public static void main(String[] args)
    {
        // Prompt the user for name, test scores, and service hours
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter the student name");
        String name = input.nextLine();
        
         System.out.println("Please enter the Math Score");
        int math = input.nextInt();
        
         System.out.println("Please enter the ELA Score");
        int ela = input.nextInt();
        
         System.out.println("Please enter the Service Hours");
        int service = input.nextInt();
        
        HSStudent hello = new HSStudent(name, math, ela, service);
        
        // Create a HSStudent object
        
        // Print the results
        
        System.out.println("Pass Math? " + hello.passMath());
          System.out.println("Pass ELA? " + hello.passEla());
          System.out.println("Completed Service Hours? " +  hello.completeService());
            System.out.println(hello);
        
        
    }
}