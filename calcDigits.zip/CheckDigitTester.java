public class CheckDigitTester {
    public static void main(String[] args) {
        
    // Constructor
    CheckDigit test = new CheckDigit();
    
    // Test cases testing getCheck
       System.out.println("run:" + test.getCheck(283415) +", expected: 6");
       System.out.println("run:" + test.getCheck(2183) +", expected: 2");
    // Test cases testing isValid
       System.out.println("run:" + test.isValid(2834150) +", expected: false");
       System.out.println("run:" + test.isValid(2834156) +", expected: true");
       System.out.println("run:" + test.isValid(2834158) +", expected: false");
       System.out.println("run:" + test.isValid(21833) +", expected: false");
       System.out.println("run:" + test.isValid(21832) +", expected: true");
       System.out.println("run:" + test.isValid(21831) +", expected: false");
    }
}