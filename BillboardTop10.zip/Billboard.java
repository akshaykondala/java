import java.util.ArrayList;
public class Billboard
{
    private ArrayList<Musician> top10 = new ArrayList<Musician>();
 
    
    public void add(Musician artist){
        
        
        if (top10.size()<10){
           if (artist.getIsPlatinum()){
            top10.add(artist);
           }
           else{
               System.out.println("Sorry, " + artist + " does not qualify for Top 10");
           }
        }
        
        else if (top10.size()>=10){
            replace(artist);
        }
        
    }
    
    public void replace(Musician artist){
        
        if (!artist.getIsPlatinum()){
            System.out.println("Sorry, " + artist + " does not qualify for Top 10");
            return;
        }
        Musician music;
        Musician min = top10.get(0);
        int minIndex = 0;
        for (int i = 1; i<top10.size(); i++){
            music = top10.get(i);
            if (music.getWeeksInTop40() < min.getWeeksInTop40()){
                min = music;
                minIndex=i;
            } 
                
        }
        
        if (artist.getWeeksInTop40()>min.getWeeksInTop40()){
          
          System.out.println("The musician " + top10.get(minIndex) + " has been replaced by " + artist + ".");
          top10.set(minIndex, artist);
    }
    
    else {
        System.out.println("Sorry, " + artist + " has less weeks in the Top 40 than the other musicians.");
    }
    
   
}
 
 
    
    //Don't make alterations to this method!
    public void printTop10()
    {
        System.out.println(top10);
    }
}