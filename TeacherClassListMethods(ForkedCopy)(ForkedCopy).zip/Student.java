public class Student
{
    /*
     * This class is complete. You do not need
     * to add anything.
     */
    private String name;
    private int grade;
    
    public Student(String name, int grade)
    {
        this.name = name;
        this.grade = grade;
    }
    
    public String getName()
    {
        return this.name;
    }
}