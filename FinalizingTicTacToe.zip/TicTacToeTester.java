import java.util.Scanner;
public class TicTacToeTester
{
    public static void main(String[] args)
    {
        //This is to help you test your methods. Feel free to add code at the end to check
        //to see if your checkWin method works!
        Scanner input  = new Scanner (System.in);
        
        
        TicTacToe game = new TicTacToe();
        System.out.println("Initial Game Board:");
        game.printBoard();
        int aRow = 0;
        int aCol = 0;
        int winner = 0;
        int counter = 0;
        while (game.checkWin()==false){
            System.out.print("Enter what row to place (0, 1, or 2): ");
            aRow = input.nextInt();
            if (!(aRow==1 || aRow == 0 || aRow == 2)){
                System.out.println("Invalid. Please input another");
                continue;
            }
            System.out.print("Enter what column to place (0, 1, or 2): ");
            aCol = input.nextInt();
             if (!(aCol==1 || aCol == 0 || aCol == 2)){
                System.out.println("Invalid. Please input another");
                continue;
            }
            if (game.pickLocation(aRow,aCol) == false){
                System.out.println("Space taken. Please input another.");
                continue;
            }
            game.takeTurn(aRow,aCol);
            game.printBoard();
            winner = game.getTurn() % 2 + 1;
            counter++;
            if (counter==9){
            System.out.println("Tie game! No winner.");
            break;
            }
        }
        
        
        if (counter!=9){
        System.out.println("Game over! Player " + winner +  " wins.");
        
        }
        
        
       
        
    
    }
}