public class BankTester
{
    public static void main(String[] args)
    {
        // Test both of your classes
        // Make sure you call every method you wrote!
        
        Account x = new Account(12, 40.3);
        System.out.println(x);
        
           StudentAccount y = new StudentAccount(12, 40.3);
        System.out.println(y);
    }
}