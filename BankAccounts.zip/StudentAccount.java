public class StudentAccount extends Account
{
    // Complete this class with Override methods.   
    

    public StudentAccount(int accountNumber, double openingBal){
        super(accountNumber, openingBal);
    }
    
    // Students get a 10% bonus on depositing
   
    
    // Add amount to balance
    @Override
    public void deposit(double amount){
      super.deposit(amount*1.1); 
       
    }
    
    // Subtract amount from balance
     @Override
    public void withdraw(double amount){
       super.withdraw(amount+1.5); 
        
    }
    
    // Should read: Regular account current balance $__.__
     @Override
    public String toString(){
       return "Student account current balance $" + super.getBalance();
       
    }
    
    
    // Students pay a $1.50 fee for withdrawing
    
    
    
    // toString() Should read: Student account current balance $__.__
    
}