public class Vocab
{
    private String[] theVocab;
    
    public Vocab(String[] arr){
        theVocab = arr;
    }
    
    public boolean findWord(String str){
        for(String theVocabs : theVocab){
            if(theVocabs.equals(str)){
                return true;
            }
        }
        return false;
    }
    
    public int countNotInVocab(String [] wordArray){
        int count = 0;
        
        for (String word : wordArray){
            if (!findWord(word)){
                count++;
            }
        }
        return count; 
    }
    
    public String[] notInVocab(String[] wordArray){
        String[] wordsNotInVocab = new String[countNotInVocab(wordArray)];
        int i = 0; 
        for (String words : wordArray){
            if (!findWord(words)){
                wordsNotInVocab[i] = words; 
                i++;
            }
            
        }
        return wordsNotInVocab;
        
    }
    
    
}